package com.tbadhit.submission_bajp_1.utils

object Const {
    const val DATABASE_NAME = "movie_db"
}
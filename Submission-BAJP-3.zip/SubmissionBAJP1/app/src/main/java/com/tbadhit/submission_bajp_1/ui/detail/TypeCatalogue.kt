package com.tbadhit.submission_bajp_1.ui.detail

enum class TypeCatalogue {
    MOVIE, TV_SHOW
}
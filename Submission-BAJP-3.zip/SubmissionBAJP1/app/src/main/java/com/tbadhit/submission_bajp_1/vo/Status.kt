package com.tbadhit.submission_bajp_1.vo

enum class Status {
    SUCCESS, ERROR, LOADING
}
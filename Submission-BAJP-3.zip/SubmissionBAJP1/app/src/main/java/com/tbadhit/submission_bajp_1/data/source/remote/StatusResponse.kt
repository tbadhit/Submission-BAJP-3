package com.tbadhit.submission_bajp_1.data.source.remote

enum class StatusResponse {
    SUCCESS, EMPTY, ERROR
}
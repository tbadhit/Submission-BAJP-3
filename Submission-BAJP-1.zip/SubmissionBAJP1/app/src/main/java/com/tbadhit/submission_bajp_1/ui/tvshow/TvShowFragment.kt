package com.tbadhit.submission_bajp_1.ui.tvshow

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.tbadhit.submission_bajp_1.databinding.FragmentTvShowBinding
import com.tbadhit.submission_bajp_1.ui.adapter.ItemAdapter

class TvShowFragment : Fragment() {

    private lateinit var fragmentTvShowBinding: FragmentTvShowBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        fragmentTvShowBinding = FragmentTvShowBinding.inflate(inflater, container, false)
        return fragmentTvShowBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val viewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        )[TvShowViewModel::class.java]
        val tvShows = viewModel.getTvShows()
        val tvShowAdapter = ItemAdapter(TV_SHOW)
        tvShowAdapter.setData(tvShows)

        fragmentTvShowBinding.lottieEmptyDataTvShow.setAnimation("empty.json")

        with(fragmentTvShowBinding.rvTvShow) {
            layoutManager = LinearLayoutManager(context)
            setHasFixedSize(true)
            adapter = tvShowAdapter
        }
    }

    companion object {
        const val TV_SHOW = 1
    }
}
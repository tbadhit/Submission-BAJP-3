package com.tbadhit.submission_bajp_1.ui.movie

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.tbadhit.submission_bajp_1.data.source.local.entity.MovieEntity
import com.tbadhit.submission_bajp_1.databinding.FragmentMovieBinding
import com.tbadhit.submission_bajp_1.ui.detail.DetailActivity
import com.tbadhit.submission_bajp_1.ui.detail.TypeCatalogue
import com.tbadhit.submission_bajp_1.utils.startActivity
import org.koin.androidx.viewmodel.ext.android.viewModel

class MovieFragment : Fragment() {

    private var _fragmentMovieBinding: FragmentMovieBinding? = null
    private val binding get() = _fragmentMovieBinding!!
    private val movieAdapter by lazy { MovieAdapter() }
    private val viewModel: MovieViewModel by viewModel()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _fragmentMovieBinding = FragmentMovieBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        with(binding.rvMovie) {
            layoutManager = LinearLayoutManager(context)
            setHasFixedSize(true)
            adapter = movieAdapter
        }

        if (activity != null) {
            binding.progressBarList.visibility = View.VISIBLE
            viewModel.getMovies().observe(requireActivity()) {movie ->
                binding.progressBarList.visibility = View.GONE
                if (movie != null) {
                    showDataMovie(movie)
                }
            }
        }
        onClick()
    }

    private fun onClick() {
        movieAdapter.onClickItem = { movieEntity ->
            requireContext().startActivity<DetailActivity>(
                DetailActivity.EXTRA_TYPE to TypeCatalogue.MOVIE.ordinal,
                DetailActivity.ID_DATA to movieEntity.id
            )
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun showDataMovie(movies: List<MovieEntity>) {
        movieAdapter.apply {
            setMovies(movies)
            notifyDataSetChanged()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _fragmentMovieBinding = null
    }
}
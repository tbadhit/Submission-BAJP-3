package com.tbadhit.submission_bajp_1.ui.tvshow

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.tbadhit.submission_bajp_1.R
import com.tbadhit.submission_bajp_1.data.source.local.entity.TvShowEntity
import com.tbadhit.submission_bajp_1.databinding.ItemsBinding
import com.tbadhit.submission_bajp_1.utils.CatalogueDiffUtil
import com.tbadhit.submission_bajp_1.utils.loadImage

class TvShowAdapter: RecyclerView.Adapter<TvShowAdapter.TvShowViewHolder>() {

    private var listTvShow = emptyList<TvShowEntity>()
    var onClickItem: ((TvShowEntity) -> Unit)? = null

    fun setTvShow(tvShows: List<TvShowEntity>) {
        val tvShowDiffUtil = CatalogueDiffUtil(listTvShow, tvShows)
        val diffUtilResult = DiffUtil.calculateDiff(tvShowDiffUtil)
        listTvShow = tvShows
        diffUtilResult.dispatchUpdatesTo(this)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TvShowViewHolder {
        val binding = ItemsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TvShowViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TvShowViewHolder, position: Int) {
        holder.bind(listTvShow[position])
    }

    override fun getItemCount(): Int = listTvShow.size

    inner class TvShowViewHolder(private val binding: ItemsBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(tvShow: TvShowEntity) {
            with(binding) {
                tvTitle.text = tvShow.name
                tvReleaseDate.text = tvShow.firstAirDate
                tvLanguage.text = tvShow.originalLanguage
                tvRate.text = tvShow.voteAverage.toString()
                tvRateCount.text = tvShow.voteCount.toString()
                imgMovie.loadImage(itemView.context.getString(R.string.url_poster, tvShow.posterPath))
            }
        }

        init {
            binding.root.setOnClickListener {
                onClickItem?.invoke(listTvShow[bindingAdapterPosition])
            }
        }

    }
}
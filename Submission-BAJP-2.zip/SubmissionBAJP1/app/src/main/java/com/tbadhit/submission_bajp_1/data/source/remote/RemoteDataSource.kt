package com.tbadhit.submission_bajp_1.data.source.remote

import android.util.Log
import com.tbadhit.submission_bajp_1.data.source.remote.response.MovieItem
import com.tbadhit.submission_bajp_1.data.source.remote.response.ResponseMovie
import com.tbadhit.submission_bajp_1.data.source.remote.response.ResponseTvShow
import com.tbadhit.submission_bajp_1.data.source.remote.response.TvShowItem
import com.tbadhit.submission_bajp_1.network.ApiConfig
import com.tbadhit.submission_bajp_1.utils.EspressoIdlingResource
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RemoteDataSource {

    fun getMovies(callback: LoadMovieCallback) {
        EspressoIdlingResource.increment()
        ApiConfig.service().getMovies().enqueue(object : Callback<ResponseMovie> {
            override fun onResponse(call: Call<ResponseMovie>, response: Response<ResponseMovie>) {
                callback.onAllMovieReceived(response.body()?.results)
                EspressoIdlingResource.decrement()
            }

            override fun onFailure(call: Call<ResponseMovie>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message.toString()}")
                EspressoIdlingResource.decrement()
            }

        })
    }

    fun getTvShow(callback: LoadTvShowCallback) {
        EspressoIdlingResource.increment()
        ApiConfig.service().getTvShow().enqueue(object : Callback<ResponseTvShow> {
            override fun onResponse(
                call: Call<ResponseTvShow>,
                response: Response<ResponseTvShow>
            ) {
                callback.onAllTvShowReceived(response.body()?.results)
                EspressoIdlingResource.decrement()
            }

            override fun onFailure(call: Call<ResponseTvShow>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message.toString()}")
                EspressoIdlingResource.decrement()
            }

        })
    }

    interface LoadMovieCallback {
        fun onAllMovieReceived(listResponseMovie: List<MovieItem>?)
    }

    interface LoadTvShowCallback {
        fun onAllTvShowReceived(listResponseTvShow: List<TvShowItem>?)
    }

    companion object {
        private val TAG = RemoteDataSource::class.java.simpleName
    }
}
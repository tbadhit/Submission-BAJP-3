package com.tbadhit.submission_bajp_1.ui.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.tbadhit.submission_bajp_1.data.source.MovieRepository
import com.tbadhit.submission_bajp_1.data.source.local.entity.MovieEntity
import com.tbadhit.submission_bajp_1.data.source.local.entity.TvShowEntity

class DetailViewModel(private val movieRepository: MovieRepository): ViewModel() {
    private lateinit var movieId: String
    private lateinit var tvShowId: String

    fun setSelectedMovie(movieId: String) {
        this.movieId = movieId
    }

    fun setSelectedTvShow(tvShowId: String) {
        this.tvShowId = tvShowId
    }

    fun getMovie(): LiveData<MovieEntity> = movieRepository.getMovieById(movieId)

    fun getTvShow(): LiveData<TvShowEntity> = movieRepository.getTvShowById(tvShowId)
}
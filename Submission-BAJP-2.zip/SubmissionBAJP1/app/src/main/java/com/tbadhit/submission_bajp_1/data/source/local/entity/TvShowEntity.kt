package com.tbadhit.submission_bajp_1.data.source.local.entity

data class TvShowEntity(
    val firstAirDate: String? = null,
    val overview: String? = null,
    val originalLanguage: String? = null,
    val posterPath: String? = null,
    val backdropPath: String? = null,
    val voteAverage: Double? = null,
    val id: Int? = null,
    val name: String? = null,
    val voteCount: Int? = null
)

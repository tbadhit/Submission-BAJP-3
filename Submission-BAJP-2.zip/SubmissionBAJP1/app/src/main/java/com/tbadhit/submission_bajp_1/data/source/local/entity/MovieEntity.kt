package com.tbadhit.submission_bajp_1.data.source.local.entity

data class MovieEntity(
    val overview: String? = null,
    val originalLanguage: String? = null,
    val originalTitle: String? = null,
    val title: String? = null,
    val posterPath: String? = null,
    val backdropPath: String? = null,
    val releaseDate: String? = null,
    val voteAverage: Double? = null,
    val id: Int? = null,
    val voteCount: Int? = null
)

package com.tbadhit.submission_bajp_1.ui.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.tbadhit.submission_bajp_1.R
import com.tbadhit.submission_bajp_1.data.source.local.entity.MovieEntity
import com.tbadhit.submission_bajp_1.data.source.local.entity.TvShowEntity
import com.tbadhit.submission_bajp_1.databinding.ActivityDetailBinding
import com.tbadhit.submission_bajp_1.utils.loadImage
import org.koin.androidx.viewmodel.ext.android.viewModel

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private val viewModel: DetailViewModel by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val type = intent.getIntExtra(EXTRA_TYPE, -1)
        val typeEnum: TypeCatalogue = TypeCatalogue.values()[type]
        val id = intent.getIntExtra(ID_DATA, -1)

        binding.apply {
            progressBarList.visibility = View.VISIBLE
            nestedScroll.visibility = View.GONE
        }

        when (typeEnum) {
            TypeCatalogue.MOVIE -> {
                viewModel.setSelectedMovie(id.toString())
                viewModel.getMovie().observe(this){movie ->
                    binding.apply {
                        progressBarList.visibility = View.GONE
                        nestedScroll.visibility = View.VISIBLE
                    }
                    loadDataMovie(movie)
                }
            }
            TypeCatalogue.TV_SHOW -> {
                viewModel.setSelectedTvShow(id.toString())
                viewModel.getTvShow().observe(this){tvShow ->
                    binding.apply {
                        progressBarList.visibility = View.GONE
                        nestedScroll.visibility = View.VISIBLE
                    }
                    loadDataTvShow(tvShow)
                }
            }
        }
    }

    private fun loadDataMovie(movie: MovieEntity) {
        with(binding) {
            tvTitle.text = movie.title
            tvDesc.text = movie.overview
            tvReleaseDate.text = movie.releaseDate
            tvLanguage.text = movie.originalLanguage
            tvRate.text = movie.voteAverage.toString()
            tvRateCount.text = movie.voteCount.toString()
            imgDetail.loadImage(getString(R.string.url_poster, movie.posterPath))
            imgBackdrop.loadImage(getString(R.string.url_poster, movie.backdropPath))
        }
    }

    private fun loadDataTvShow(tvShow: TvShowEntity) {
        with(binding) {
            tvTitle.text = tvShow.name
            tvDesc.text = tvShow.overview
            tvReleaseDate.text = tvShow.firstAirDate
            tvLanguage.text = tvShow.originalLanguage
            tvRate.text = tvShow.voteAverage.toString()
            tvRateCount.text = tvShow.voteCount.toString()
            imgDetail.loadImage(getString(R.string.url_poster, tvShow.posterPath))
            imgBackdrop.loadImage(getString(R.string.url_poster, tvShow.backdropPath))
        }
    }

    companion object {
        const val ID_DATA = "id_data"
        const val EXTRA_TYPE = "extra_type"
    }
}
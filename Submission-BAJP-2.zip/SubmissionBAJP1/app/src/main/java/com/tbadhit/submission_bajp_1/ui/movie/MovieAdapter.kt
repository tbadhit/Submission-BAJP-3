package com.tbadhit.submission_bajp_1.ui.movie

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.tbadhit.submission_bajp_1.R
import com.tbadhit.submission_bajp_1.data.source.local.entity.MovieEntity
import com.tbadhit.submission_bajp_1.databinding.ItemsBinding
import com.tbadhit.submission_bajp_1.utils.CatalogueDiffUtil
import com.tbadhit.submission_bajp_1.utils.loadImage

class MovieAdapter : RecyclerView.Adapter<MovieAdapter.MovieViewHolder>() {

    private var listMovies = emptyList<MovieEntity>()
    var onClickItem: ((MovieEntity) -> Unit)? = null

    fun setMovies(movies: List<MovieEntity>) {
        val movieDiffUtil = CatalogueDiffUtil(listMovies, movies)
        val diffUtilResult = DiffUtil.calculateDiff(movieDiffUtil)
        listMovies = movies
        diffUtilResult.dispatchUpdatesTo(this)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int
    ): MovieViewHolder {
        val itemListBinding = ItemsBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return MovieViewHolder(itemListBinding)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        holder.bind(listMovies[position])
    }

    override fun getItemCount(): Int = listMovies.size

    inner class MovieViewHolder(private val binding: ItemsBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(movie: MovieEntity) {
            with(binding) {
                tvTitle.text = movie.title
                tvReleaseDate.text = movie.releaseDate
                tvLanguage.text = movie.originalLanguage
                tvRate.text = movie.voteAverage.toString()
                tvRateCount.text = movie.voteCount.toString()
                imgMovie.loadImage(itemView.context.getString(R.string.url_poster, movie.posterPath))
            }
        }

        init {
            binding.root.setOnClickListener {
                onClickItem?.invoke(listMovies[bindingAdapterPosition])
            }
        }

    }

}
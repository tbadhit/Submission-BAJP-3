package com.tbadhit.submission_bajp_1.data.source

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.tbadhit.submission_bajp_1.data.source.remote.RemoteDataSource
import com.tbadhit.submission_bajp_1.utils.DataMovie
import com.tbadhit.submission_bajp_1.utils.DataTvShow
import com.tbadhit.submission_bajp_1.utils.LiveDataTestUtil
import junit.framework.TestCase
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import com.nhaarman.mockitokotlin2.any
import org.mockito.Mockito.*
import org.mockito.Mockito.mock

class MovieRepositoryTest {

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    private val remote = mock(RemoteDataSource::class.java)
    private val movieRepository = FakeMovieRepository(remote)
    private val movieResponse = DataMovie.generateRemoteDummyMovies()
    private val movieId = movieResponse[0].id.toString()
    private val tvShowResponse = DataTvShow.generateRemoteDummyTvShow()
    private val tvShowId = tvShowResponse[0].id.toString()

    @Test
    fun testGetAllMovies() {
        doAnswer { invocationOnMock ->
            (invocationOnMock.arguments[0] as RemoteDataSource.LoadMovieCallback)
                .onAllMovieReceived(movieResponse)
            null
        }.`when`(remote).getMovies(any())
        val movieEntities = LiveDataTestUtil.getValue(movieRepository.getAllMovies())
        verify(remote).getMovies(any())
        TestCase.assertNotNull(movieEntities)
        assertEquals(movieResponse.size.toLong(), movieEntities.size.toLong())
    }

    @Test
    fun getMovieById() {
        com.nhaarman.mockitokotlin2.doAnswer { invocationOnMock ->
            (invocationOnMock.arguments[0] as RemoteDataSource.LoadMovieCallback)
                .onAllMovieReceived(movieResponse)
            null
        }.`when`(remote).getMovies(any())
        val movieEntity = LiveDataTestUtil.getValue(movieRepository.getMovieById(movieId))
        val movieResponse = movieResponse[0]
        com.nhaarman.mockitokotlin2.verify(remote).getMovies(any())
        TestCase.assertNotNull(movieEntity)
        assertEquals(movieResponse.overview, movieEntity.overview)
        assertEquals(movieResponse.originalLanguage, movieEntity.originalLanguage)
        assertEquals(movieResponse.originalTitle, movieEntity.originalTitle)
        assertEquals(movieResponse.title, movieEntity.title)
        assertEquals(movieResponse.posterPath, movieEntity.posterPath)
        assertEquals(movieResponse.backdropPath, movieEntity.backdropPath)
        assertEquals(movieResponse.releaseDate, movieEntity.releaseDate)
        assertEquals(movieResponse.voteAverage, movieEntity.voteAverage)
        assertEquals(movieResponse.id, movieEntity.id)
        assertEquals(movieResponse.voteCount, movieEntity.voteCount)
    }

    @Test
    fun getAllTvShow() {
        com.nhaarman.mockitokotlin2.doAnswer { invocationOnMock ->
            (invocationOnMock.arguments[0] as RemoteDataSource.LoadTvShowCallback)
                .onAllTvShowReceived(tvShowResponse)
            null
        }.`when`(remote).getTvShow(any())
        val tvShowEntities = LiveDataTestUtil.getValue(movieRepository.getAllTvShow())
        com.nhaarman.mockitokotlin2.verify(remote).getTvShow(any())
        TestCase.assertNotNull(tvShowEntities)
        assertEquals(tvShowResponse.size.toLong(), tvShowEntities.size.toLong())
    }

    @Test
    fun getTvShowId() {
        com.nhaarman.mockitokotlin2.doAnswer { invocationOnMock ->
            (invocationOnMock.arguments[0] as RemoteDataSource.LoadTvShowCallback)
                .onAllTvShowReceived(tvShowResponse)
            null
        }.`when`(remote).getTvShow(any())
        val tvShowEntity = LiveDataTestUtil.getValue(movieRepository.getTvShowById(tvShowId))
        val tvShowResponse = tvShowResponse[0]
        com.nhaarman.mockitokotlin2.verify(remote).getTvShow(any())
        TestCase.assertNotNull(tvShowEntity)
        assertEquals(tvShowResponse.firstAirDate, tvShowEntity.firstAirDate)
        assertEquals(tvShowResponse.overview, tvShowEntity.overview)
        assertEquals(tvShowResponse.originalLanguage, tvShowEntity.originalLanguage)
        assertEquals(tvShowResponse.posterPath, tvShowEntity.posterPath)
        assertEquals(tvShowResponse.backdropPath, tvShowEntity.backdropPath)
        assertEquals(tvShowResponse.voteAverage, tvShowEntity.voteAverage)
        assertEquals(tvShowResponse.id, tvShowEntity.id)
        assertEquals(tvShowResponse.name, tvShowEntity.name)
        assertEquals(tvShowResponse.voteCount, tvShowEntity.voteCount)
    }

}
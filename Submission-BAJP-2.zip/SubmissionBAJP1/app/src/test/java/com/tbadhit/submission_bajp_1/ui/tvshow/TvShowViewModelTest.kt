package com.tbadhit.submission_bajp_1.ui.tvshow

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.tbadhit.submission_bajp_1.data.source.MovieRepository
import com.tbadhit.submission_bajp_1.data.source.local.entity.TvShowEntity
import com.tbadhit.submission_bajp_1.utils.DataTvShow
import junit.framework.TestCase
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.Mockito.verify

class TvShowViewModelTest {

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var movieRepository: MovieRepository

    @Mock
    private lateinit var observer: Observer<List<TvShowEntity>>

    private lateinit var viewModel: TvShowViewModel

    @Before
    fun setUp() {
        viewModel = TvShowViewModel(movieRepository)
    }

    @Test
    fun testGetTvShows() {
        val dataDummyTvShow = DataTvShow.generateDummyTvShow()
        val tvShow = MutableLiveData<List<TvShowEntity>>()
        tvShow.value = dataDummyTvShow

        Mockito.`when`(movieRepository.getAllTvShow()).thenReturn(tvShow)
        val tvShowEntity = viewModel.getTvShows().value
        verify(movieRepository).getAllTvShow()
        TestCase.assertNotNull(tvShowEntity)
        TestCase.assertEquals(2, tvShowEntity?.size)

        viewModel.getTvShows().observeForever(observer)
        verify(observer).onChanged(dataDummyTvShow)

    }
}
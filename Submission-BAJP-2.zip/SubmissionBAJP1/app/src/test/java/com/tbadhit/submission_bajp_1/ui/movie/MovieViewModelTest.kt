package com.tbadhit.submission_bajp_1.ui.movie

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.tbadhit.submission_bajp_1.data.source.MovieRepository
import com.tbadhit.submission_bajp_1.data.source.local.entity.MovieEntity
import com.tbadhit.submission_bajp_1.utils.DataMovie
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.Mockito.verify

class MovieViewModelTest {

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    private lateinit var viewModel: MovieViewModel

    @Mock
    private lateinit var movieRepository: MovieRepository

    @Mock
    private lateinit var observer: Observer<List<MovieEntity>>

    @Before
    fun setUp() {
        viewModel = MovieViewModel(movieRepository)
    }

    @Test
    fun testGetMovies() {
        val dataDummyMovie = DataMovie.generateDummyMovie()
        val movies = MutableLiveData<List<MovieEntity>>()
        movies.value = dataDummyMovie

        Mockito.`when`(movieRepository.getAllMovies()).thenReturn(movies)
        val movieEntity = viewModel.getMovies().value
        verify(movieRepository).getAllMovies()
        assertNotNull(movieEntity)
        assertEquals(2, movieEntity?.size)
        viewModel.getMovies().observeForever(observer)
        verify(observer).onChanged(dataDummyMovie)
    }
}
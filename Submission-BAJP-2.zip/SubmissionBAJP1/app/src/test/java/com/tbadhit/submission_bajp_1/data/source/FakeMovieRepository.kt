package com.tbadhit.submission_bajp_1.data.source

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.tbadhit.submission_bajp_1.data.source.local.entity.MovieEntity
import com.tbadhit.submission_bajp_1.data.source.local.entity.TvShowEntity
import com.tbadhit.submission_bajp_1.data.source.remote.RemoteDataSource
import com.tbadhit.submission_bajp_1.data.source.remote.response.MovieItem
import com.tbadhit.submission_bajp_1.data.source.remote.response.TvShowItem

class FakeMovieRepository(private val remoteDataSource: RemoteDataSource) : MovieDataSource {
    override fun getAllMovies(): LiveData<List<MovieEntity>> {
        val movieResult = MutableLiveData<List<MovieEntity>>()
        remoteDataSource.getMovies(object : RemoteDataSource.LoadMovieCallback {
            override fun onAllMovieReceived(listResponseMovie: List<MovieItem>?) {
                val movieList = ArrayList<MovieEntity>()
                if (listResponseMovie != null) {
                    for (movie in listResponseMovie) {
                        with(movie) {
                            movieList.add(
                                MovieEntity(
                                    overview,
                                    originalLanguage,
                                    originalTitle,
                                    title,
                                    posterPath,
                                    backdropPath,
                                    releaseDate,
                                    voteAverage,
                                    id,
                                    voteCount
                                )
                            )
                        }
                    }
                }
                movieResult.postValue(movieList)
            }
        })
        return movieResult
    }

    override fun getMovieById(movieId: String): LiveData<MovieEntity> {
        val movieResult = MutableLiveData<MovieEntity>()
        remoteDataSource.getMovies(object : RemoteDataSource.LoadMovieCallback {
            override fun onAllMovieReceived(listResponseMovie: List<MovieItem>?) {
                lateinit var movie: MovieEntity
                if (listResponseMovie != null) {
                    for (itemMovie in listResponseMovie) {
                        if (movieId == itemMovie.id.toString()) {
                            with(itemMovie) {
                                movie = MovieEntity(
                                    overview,
                                    originalLanguage,
                                    originalTitle,
                                    title,
                                    posterPath,
                                    backdropPath,
                                    releaseDate,
                                    voteAverage,
                                    id,
                                    voteCount
                                )
                            }
                        }
                    }
                }
                movieResult.postValue(movie)
            }
        })
        return movieResult
    }

    override fun getAllTvShow(): LiveData<List<TvShowEntity>> {
        val tvShowResult = MutableLiveData<List<TvShowEntity>>()
        remoteDataSource.getTvShow(object : RemoteDataSource.LoadTvShowCallback {
            override fun onAllTvShowReceived(listResponseTvShow: List<TvShowItem>?) {
                val tvShowList = ArrayList<TvShowEntity>()
                if (listResponseTvShow != null) {
                    for (tvShow in listResponseTvShow) {
                        with(tvShow) {
                            tvShowList.add(
                                TvShowEntity(
                                    firstAirDate,
                                    overview,
                                    originalLanguage,
                                    posterPath,
                                    backdropPath,
                                    voteAverage,
                                    id,
                                    name,
                                    voteCount,
                                )
                            )
                        }
                    }
                }
                tvShowResult.postValue(tvShowList)
            }

        })
        return tvShowResult
    }

    override fun getTvShowById(tvShowId: String): LiveData<TvShowEntity> {
        val tvShowResult = MutableLiveData<TvShowEntity>()
        remoteDataSource.getTvShow(object : RemoteDataSource.LoadTvShowCallback {
            override fun onAllTvShowReceived(listResponseTvShow: List<TvShowItem>?) {
                lateinit var tvShow: TvShowEntity
                if (listResponseTvShow != null) {
                    for (itemTvShow in listResponseTvShow) {
                        if (tvShowId == itemTvShow.id.toString()) {
                            with(itemTvShow) {
                                tvShow = TvShowEntity(
                                    firstAirDate,
                                    overview,
                                    originalLanguage,
                                    posterPath,
                                    backdropPath,
                                    voteAverage,
                                    id,
                                    name,
                                    voteCount
                                )
                            }
                        }
                    }
                }
                tvShowResult.postValue(tvShow)
            }

        })
        return tvShowResult
    }
}